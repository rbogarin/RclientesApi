﻿using Repository.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Logica
{
    public class FacturaService
    {
        
        FacturaRepository facturaRepository;
        public FacturaService(string connectionString)
        {
            facturaRepository = new FacturaRepository(connectionString);
        }
        public bool add(FacturaModel modelo)
        {
            return facturaRepository.add(modelo);
        }
        private bool validacionFactura(FacturaModel factura)
        {
            if (factura == null)
                return false;
            if (string.IsNullOrEmpty(factura.Nro_Factura))
                return false;
            return true;
        }
    }
}
}
