﻿using Repository.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Logica
{
    public class ClienteService
    {
        ClientesRepository clientesRepository;
            public ClienteService(string connectionString)
            {
            clientesRepository = new ClientesRepository(connectionString);
            }
        public bool add(ClienteModel modelo)
        {
            return clientesRepository.add(modelo);
        }
        private bool validacionCliente(ClienteModel cliente)
        {
            if (cliente == null)
                return false;
            if (string.IsNullOrEmpty(cliente.Nombre))
                return false;
            return true;
        }
    }
}
