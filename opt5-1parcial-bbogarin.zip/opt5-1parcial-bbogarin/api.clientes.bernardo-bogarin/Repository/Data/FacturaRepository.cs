﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Data
{
    public class FacturaRepository : IFactura
    {
        public bool add(FacturaModel cliente)
        {
            throw new NotImplementedException();
        }

        public FacturaModel get(int Id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<FacturaModel> list()
        {
            throw new NotImplementedException();
        }

        public bool remove(FacturaModel cliente)
        {
            throw new NotImplementedException();
        }

        public bool update(FacturaModel cliente)
        {
            throw new NotImplementedException();
        }
    }
}
