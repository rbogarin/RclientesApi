﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace Repository.Data
{
    public class ClientesRepository : ICliente
    {
       
        private IDbConnection conexionDB;
        public ClientesRepository(string _connectionString)
        {
            conexionDB = new DbConection(_connectionString).dbConnection();
        }
        public bool add(ClienteModel cliente)
        {
            try
            {
                if (conexionDB.Execute("Insert into Cliente(Nombre, Apellido, Documento) values(@Nombre, @Apellido, @Documento)", cliente) > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public bool update(ClienteModel cliente int id)
        {
            try
            {
                if (conexionDB.Execute("UPDATE Cliente SET " +
                    "Nombre=@Nombre, " +
                    "Apellido=@Apellido," +
                    $"Documento=@Documento) where Id = {id}", cliente) > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {

                public ClienteModel get(int id)
                {
                    throw new NotImplementedException();
                }

                public IEnumerable<ClienteModel> list()
                {
                    throw new NotImplementedException();
                }
                public bool remove(ClienteModel cliente) => throw new NotImplementedException();

                public bool update(ClienteModel cliente)
                {
                    throw new NotImplementedException();
                }
            }
    }   }

}
