﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Data
{
    internal interface ICliente
    {
        bool add(ClienteModel cliente);
        bool remove(ClienteModel cliente);
        bool update(ClienteModel cliente);
        ClienteModel get(int Id);
        IEnumerable<ClienteModel> list();
        bool Update(ClienteModel cliente, int id);
    }
}
