﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Data
{
    internal interface IFactura
    {
        bool add(FacturaModel cliente);
        bool remove(FacturaModel cliente);
        bool update(FacturaModel cliente);
        FacturaModel get(int Id);
        IEnumerable<FacturaModel> list();
    }
}
